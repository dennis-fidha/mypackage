from mypackage import myModule

def test_top_n():
    '''
    make sure top_n works using the assert command
    which is used for unit testing
    '''
    
    assert myModule.top_n([8,3,2,7,4], 3) == [8,7,4], 'Incorrect'
    assert myModule.top_n([10,1,12,9,2], 2) == [12,10], 'Incorrect'
    assert myModule.top_n([1,2,3,4,5], 5) == [5,4,3,2,1], 'Incorrect'